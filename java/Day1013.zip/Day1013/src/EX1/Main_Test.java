package EX1;

public class Main_Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new test1();
	}

}
