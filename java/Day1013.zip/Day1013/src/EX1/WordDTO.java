package EX1;

public class WordDTO {
	
	String eng=null;
	String kor=null;
	String impor=null;
	String info=null;
	public String getEng() {
		return eng;
	}
	public void setEng(String eng) {
		this.eng = eng;
	}
	public String getKor() {
		return kor;
	}
	public void setKor(String kor) {
		this.kor = kor;
	}
	public String getImpor() {
		return impor;
	}
	public void setImpor(String impor) {
		this.impor = impor;
	}
	public String getInfo() {
		return info;
	}
	public void setInfo(String info) {
		this.info = info;
	}

}
