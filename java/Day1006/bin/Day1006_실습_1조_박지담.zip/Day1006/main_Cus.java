package Day1006;

public class main_Cus {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		cusManager cm = new cusManager();
		cm.run();
	}

}
