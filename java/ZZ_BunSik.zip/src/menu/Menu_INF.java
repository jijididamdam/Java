package menu;

public interface Menu_INF {
	
	public void info();
	public void inputBasket();
	public void payCount();
	

}
