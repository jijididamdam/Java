package main;

import order.OrderMGE;

public class Main {
	public static void main(String[] args) {
		new OrderMGE();
	}
}
